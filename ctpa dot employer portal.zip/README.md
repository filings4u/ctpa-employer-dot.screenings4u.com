# screenings4u DOT Employer Portal — Steps 7 & 8 Access Model

Domain: `https://employer-dot.screenings4u.com`
Portal code: `employer_dot`

This build implements the two DOT Employer access modes requested for screenings4u.

## 1. C/TPA customer DOT Employer customer

A C/TPA can create and invite DOT Employer customers to the Employer DOT portal. New C/TPA Employer creation now creates a separate child Employer tenant, so one C/TPA can support large numbers of Employer customers without the previous one-Employer-per-tenant collision. The C/TPA portal also includes CSV bulk import and processes large files in batches of 100 Employers.

Employer Customers use the internal `dot_employer_ctpa_C/TPA customer` plan and `employer_dot` portal access. Their portal is customer-facing and intentionally restricted:

- view company/DOT configuration managed by the C/TPA;
- view programs, pools, selections, results, compliance, reports, and managed workflow data when entitled;
- add DOT employees/drivers;
- request new tests, but not manage testing workflow/status after submission;
- upload/link/view/download documents, but not perform administrative document record changes;
- create support requests routed to the C/TPA;
- receive and reply to C/TPA messages/notifications;
- view C/TPA-issued invoices in Billing;
- no Team/staff-management controls;
- no program/pool/compliance/company-administration mutations.

If the C/TPA has Enterprise white label enabled, its C/TPA branding is returned for this portal and for the Employee/Driver portal.

Platform Admin support, messaging, invoicing, Employer directory/context, access management, testing, results, compliance, documents, reporting, selections, and profile actions now reject or exclude C/TPA-managed Employer customer accounts.

## 2. Direct/self-managed DOT Employer

A DOT Employer that purchases a plan directly from screenings4u receives self-managed `employer_dot` access, scoped to the purchased plan.

Direct Employers:

- must have an active DOT agency affiliation: FMCSA, FAA, FRA, FTA, PHMSA, or USCG before regulated DOT operational actions;
- can manage their DOT company according to plan entitlements;
- can add DOT employees/drivers and invite them to the DOT Employee/Driver portal;
- can receive screenings4u Admin messages and reply;
- receive screenings4u support routing;
- use Billing to view/download/pay screenings4u Admin-issued invoices;
- invoice payment links use the global `https://screenings4u.com/checkout.html` flow.

### Enterprise Employer white label

`dot_employer_enterprise` now has White Label enabled. The new `branding.html` page lets the direct Employer configure its portal name, logo, primary color, and accent color. Employer branding is also returned to the DOT Employee/Driver portal backend so employee/driver views can inherit the Employer's brand.

## Employee / Driver portal access

Direct Employers can invite a DOT-covered employee/driver from the People page. Employees with a CDL are tagged for `driver_dot`; other DOT-covered workers use `employee_dot`. Both currently point to `https://employee-dot.screenings4u.com`.

The Employee/Driver backend is now enforced as view-only. It can expose the worker's assigned DOT program/testing/results/documents/notifications data according to the Employer plan, but profile editing, credential submission, and policy mutation actions are blocked.

## Billing behavior

Employer Billing is context-aware:

- Employer customer: C/TPA-issued invoices only.
- Direct Employer: screenings4u Admin-issued invoices only.

For direct Employers, drafts and unsent platform invoices are hidden. Payment goes through the global screenings4u checkout URL.

## Support and notifications

Employer Customer support tickets are owned by the C/TPA and are hidden from Platform Admin Support. Direct Employer tickets remain owned by screenings4u Platform Support.

Employer Customer message threads use the C/TPA messaging channel. Direct Employer threads use the screenings4u Platform channel.

## Review workspaces

`aerving1@gmail.com` has review access to:

- DOT Employer Essential
- DOT Employer Professional
- DOT Employer Enterprise
- DOT Employer — C/TPA Customer Review

The C/TPA customer review workspace is attached to the DOT C/TPA Enterprise review account to verify inherited C/TPA branding and C/TPA-customer restrictions.

## Backend revisions used by this step

Key live functions updated include `workforce-employer-management`, `workforce-employer-pools`, `workforce-employer-testing`, `workforce-employer-documents`, `workforce-employer-notifications`, `workforce-support`, `workforce-admin-support`, `workforce-admin-notifications`, `workforce-invoice-portal`, `workforce-admin-invoicing`, `workforce-invoice-public`, `workforce-ctpa-employers`, and `workforce-employee-portal`, plus Platform Admin Employer endpoints that now reject C/TPA-managed customer accounts.

## Step 9 — Legacy Workforce access retired

The legacy shared Workforce portal access layer has been retired from the live backend. Employer DOT now authorizes through the canonical `organization_portal_access` record for `employer_dot` only. The old `employer_portal_access` and `ctpa_portal_access` tables were archived into an audit-only snapshot and removed.

Legacy `employer_workforce` / `ctpa_workforce` organization access rows were retired. Existing compliance/customer data was not deleted. DOT Employer accounts remain on `employer_dot`; NON-DOT records are preserved but no longer receive access through the retired Workforce surface while their separate product/portal is built.

The shared checkout endpoint now accepts Employer purchases only when the selected plan is a `dot_employer_*` plan and forces the Employer classification to DOT. DOT Employer purchases require a USDOT number. C/TPA checkout similarly accepts only `dot_ctpa_*` plans.


Branding load UX fix: authenticated pages now show a neutral loading card while account branding resolves. The portal shell remains hidden until the correct C/TPA or screenings4u colors/logo are ready, preventing both blank-screen loading and brand-color flashing. CSS cache version 17.


### Branding loader performance fix
- Replaced the text loading card with a neutral CSS spinner.
- Branding is prefetched in parallel with session-context when a workspace is already selected.
- Branding is cached per membership for 30 minutes so page-to-page navigation can render the correct logo/colors immediately.
- Session lookup is reused within the page instead of repeatedly calling Supabase auth.
- Page data rendering now starts in parallel with branding resolution.
- Cache versions: portal.css?v=18, app.js?v=19.


## Company profile typography fix
- Reduced Company summary card values (Name, Email, Phone, Status) from the global 24px metric size to 17px desktop / 16px mobile.
- Added safe wrapping for long Employer names and email addresses without changing KPI metrics elsewhere in the portal.


## Employer Customer corrections — 2026-09-19
- Pools and Notifications spacing tightened for Employer customers.
- Add Driver / Employee now captures the full worker contact/profile set supported by the employees table.
- C/TPA Customer Order Services no longer sells screenings4u services directly. It loads Admin-enabled DOT services and submits requests to the C/TPA.
- Admin global service controls are live through `workforce-admin-ctpa-operations` (`service_catalog`, `set_service_catalog`).
- Sidebar and mobile navigation now normalize page IDs before applying the active state, including hyphenated pages such as Order Services.
- C/TPA Customer Support relationship/status copy no longer references screenings4u as the customer's support owner.
- Frontend cache versions: portal.css v20, app.js v21, notifications.js v2, support.js v3, pools.js v4.
- Live Edge Functions: workforce-employer-management v21; workforce-admin-ctpa-operations v11.

## C/TPA customer naming + Pools spacing correction — 2026-09-19
- Removed customer-facing use of the old "Customer" wording throughout the Employer DOT website.
- The C/TPA company name from the live Employer→C/TPA relationship is now used in the shell, breadcrumb, hero kicker, Order Services, Notifications, Billing, Support, Company messaging, and Pools where a provider/company name is required.
- The internal access key remains unchanged in the backend, but it is no longer exposed as customer-facing copy.
- Pools now has explicit vertical gaps between the C/TPA notice, KPI row, Consortium Participation panel, and Pool Membership panel; empty-state padding is balanced instead of sections touching.
- Live backend revisions: dot-session-context v26; workforce-employer-management v22.
- Frontend cache versions: portal.css?v=22 and app.js?v=23.
