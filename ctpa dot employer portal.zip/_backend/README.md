# screenings4u C/TPA Sponsored Employer Portal — Isolated Runtime

Portal code: `ctpa_employer_dot`

Dedicated Edge Functions:
- `ctpa-employer-dot-session`
- `ctpa-employer-dot-actions`
- `ctpa-employer-dot-distribution`

This portal does not call the shared `dot-session-context`, `dot-portal-actions`, or `dot-distribution-runtime` functions at runtime. Existing page modules keep their operation names, but the local config routes those calls to `ctpa-employer-dot-actions`.

Client validation is owned by `assets/js/validation.js`. Server validation is enforced by the dedicated actions function.
